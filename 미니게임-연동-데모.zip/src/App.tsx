import React, { useState, useEffect } from 'react';
import { getStamps, saveStamp, resetStamps } from './utils/storage';
import { StampsMap } from './types';
import { MainApp } from './components/MainApp';
import { MiniGameApp } from './components/MiniGameApp';
import { Gamepad2, Smartphone, HelpCircle } from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'main' | 'minigame'>('main');
  const [stamps, setStamps] = useState<StampsMap>(() => getStamps());
  const [lastProcessedGame, setLastProcessedGame] = useState<string | null>(null);
  const [currentGameId, setCurrentGameId] = useState<string>('practice-game');
  const [systemLog, setSystemLog] = useState<string>('시스템 준비 완료. 사용자 동작 대기 중...');
  const [myMainUrl, setMyMainUrl] = useState<string>(() => {
    return window.location.origin + window.location.pathname;
  });

  // On initial mount & whenever URL query params change
  useEffect(() => {
    const handleUrlCheck = () => {
      const params = new URLSearchParams(window.location.search);
      const game = params.get('game');
      const result = params.get('result');
      const view = params.get('view');
      const returnUrl = params.get('mainUrl');

      if (returnUrl) {
        setMyMainUrl(returnUrl);
      }

      if (view === 'game') {
        setCurrentPage('minigame');
      }

      // Requirement: Check if game={miniGameId}&result=success arrived
      if (game && result === 'success') {
        // 1) Save to localStorage.stamps
        const updated = saveStamp(game);
        setStamps(updated);
        setLastProcessedGame(game);
        setSystemLog(`[URL 감지] game="${game}" & result="success" 감지 → localStorage.stamps 업데이트 완료`);

        // 2) Remove game & result params from URL to prevent duplicate processing on refresh
        params.delete('game');
        params.delete('result');
        const cleanSearch = params.toString();
        const cleanUrl =
          window.location.pathname + (cleanSearch ? `?${cleanSearch}` : '') + window.location.hash;
        
        window.history.replaceState({}, document.title, cleanUrl);
      }
    };

    handleUrlCheck();
    window.addEventListener('popstate', handleUrlCheck);
    return () => window.removeEventListener('popstate', handleUrlCheck);
  }, []);

  // Handle navigating to Mini Game from Main App
  const handleNavigateToMiniGame = (gameId: string) => {
    setCurrentGameId(gameId);
    setCurrentPage('minigame');
    setSystemLog(`[이동] 메인 앱 → 미니게임("${gameId}") 이동 (Target return URL 전달)`);

    // Update URL query view=game so the state is also reflected in browser history if desired
    const params = new URLSearchParams(window.location.search);
    params.set('view', 'game');
    params.set('gameId', gameId);
    params.set('mainUrl', myMainUrl);
    const newUrl = window.location.pathname + '?' + params.toString();
    window.history.pushState({}, '', newUrl);
  };

  // Handle returning from Mini Game to Main App
  const handleReturnToMain = (resultQuery?: string) => {
    setCurrentPage('main');

    if (resultQuery) {
      // Simulate real browser redirect with result parameter: MainAppUrl?game=...&result=success
      const targetSearch = resultQuery ? `?${resultQuery}` : '';

      // Apply the search parameters
      const params = new URLSearchParams(resultQuery);
      const game = params.get('game');
      const result = params.get('result');

      if (game && result === 'success') {
        // Save to localStorage
        const updated = saveStamp(game);
        setStamps(updated);
        setLastProcessedGame(game);
        setSystemLog(`[리다이렉트 성공] "${game}" 성공 결과 수신 → localStorage 저장 및 URL 파라미터 자동 정화`);
      }

      // Push clean state back to main app view
      window.history.pushState({}, '', window.location.pathname);
    } else {
      setSystemLog('[이동] 미니게임 → 메인 앱 복귀 (결과 없음)');
      window.history.pushState({}, '', window.location.pathname);
    }
  };

  // Handle resetting stamps
  const handleResetStamps = () => {
    const defaultData = resetStamps();
    setStamps(defaultData);
    setLastProcessedGame(null);
    setSystemLog('[초기화] localStorage.stamps 데이터가 초기 상태로 리셋되었습니다.');
  };

  const isAcquired = stamps['practice-game']?.acquired;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-12 selection:bg-indigo-500 selection:text-white flex flex-col">
      {/* Top Header / Protocol Navigation Bar */}
      <header className="bg-slate-900 text-slate-200 border-b border-slate-800 shadow-md">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-white flex items-center gap-2">
                App-to-App Protocol Simulator
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                v1.0.4
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              메인 앱 ↔ 미니게임 간 데이터 전달 및 localStorage 자동 수집 시스템
            </p>
          </div>

          <div className="flex items-center gap-3 self-end sm:self-auto">
            {/* Storage Status Tag */}
            <div className="hidden md:flex px-3 py-1 bg-slate-800 border border-slate-700 rounded-md shadow-xs flex-col items-end">
              <span className="text-[9px] uppercase font-semibold text-slate-400 block tracking-wider">
                LOCAL STORAGE STATUS
              </span>
              <span className={`font-mono text-xs font-bold ${isAcquired ? 'text-emerald-400' : 'text-indigo-400'}`}>
                {isAcquired ? 'STAMP ACQUIRED' : 'READY'}
              </span>
            </div>

            {/* Page Mode Switcher */}
            <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl border border-slate-700">
              <button
                onClick={() => handleReturnToMain()}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  currentPage === 'main'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                메인 앱
              </button>
              <button
                onClick={() => handleNavigateToMiniGame('practice-game')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  currentPage === 'minigame'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                <Gamepad2 className="w-3.5 h-3.5" />
                미니게임 앱
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 pt-6">
        {currentPage === 'main' ? (
          <MainApp
            myUrl={myMainUrl}
            stamps={stamps}
            lastProcessedGame={lastProcessedGame}
            onNavigateToMiniGame={handleNavigateToMiniGame}
            onResetStamps={handleResetStamps}
          />
        ) : (
          <MiniGameApp
            mainUrl={myMainUrl}
            gameId={currentGameId}
            onReturnToMain={handleReturnToMain}
          />
        )}
      </main>

      {/* High-Density System Log Footer */}
      <footer className="max-w-5xl w-full mx-auto px-4 sm:px-6 mt-8">
        <div className="bg-slate-900 rounded-xl p-3.5 border border-slate-800 shadow-lg flex items-center gap-3 text-xs font-mono">
          <span className="text-emerald-400 font-bold px-2 py-0.5 bg-emerald-400/10 rounded border border-emerald-400/20 shrink-0 text-[10px] tracking-wider uppercase">
            SYSTEM LOG
          </span>
          <p className="text-slate-300 truncate">
            [{new Date().toLocaleTimeString('ko-KR')}] {systemLog}
          </p>
        </div>
      </footer>
    </div>
  );
}
