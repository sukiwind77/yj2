export interface StampItem {
  gameId: string;
  gameName: string;
  acquired: boolean;
  acquiredAt?: string;
}

export type StampsMap = Record<string, StampItem>;

export interface GameInfo {
  id: string;
  name: string;
  description: string;
  icon: string;
}
