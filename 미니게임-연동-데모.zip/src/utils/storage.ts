import { StampsMap, StampItem } from '../types';

const STAMPS_KEY = 'stamps';

export const DEFAULT_STAMPS: StampsMap = {
  'practice-game': {
    gameId: 'practice-game',
    gameName: '연습 미니게임',
    acquired: false,
  },
  'jump-game': {
    gameId: 'jump-game',
    gameName: '점프점프 미니게임',
    acquired: false,
  },
  'quiz-game': {
    gameId: 'quiz-game',
    gameName: '상식 퀴즈 미니게임',
    acquired: false,
  },
};

export function getStamps(): StampsMap {
  try {
    const raw = localStorage.getItem(STAMPS_KEY);
    if (!raw) {
      return DEFAULT_STAMPS;
    }
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_STAMPS, ...parsed };
  } catch (err) {
    console.error('Failed to load stamps from localStorage:', err);
    return DEFAULT_STAMPS;
  }
}

export function saveStamp(gameId: string): StampsMap {
  const current = getStamps();
  const gameName = current[gameId]?.gameName || `${gameId} 미니게임`;
  
  const updated: StampsMap = {
    ...current,
    [gameId]: {
      gameId,
      gameName,
      acquired: true,
      acquiredAt: new Date().toLocaleString('ko-KR'),
    },
  };

  try {
    localStorage.setItem(STAMPS_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save stamp to localStorage:', err);
  }

  return updated;
}

export function resetStamps(): StampsMap {
  try {
    localStorage.removeItem(STAMPS_KEY);
  } catch (err) {
    console.error('Failed to clear stamps from localStorage:', err);
  }
  return DEFAULT_STAMPS;
}
