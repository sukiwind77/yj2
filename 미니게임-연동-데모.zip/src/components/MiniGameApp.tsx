import React, { useState, useEffect } from 'react';
import { Gamepad2, Trophy, ArrowLeft, Send, Sparkles, AlertCircle, RefreshCw, CheckCircle2 } from 'lucide-react';

interface Props {
  mainUrl: string;
  gameId: string;
  onReturnToMain: (resultQuery?: string) => void;
}

export const MiniGameApp: React.FC<Props> = ({ mainUrl, gameId, onReturnToMain }) => {
  const [score, setScore] = useState(0);
  const [gameEnded, setGameEnded] = useState(false);
  const [clicksNeeded, setClicksNeeded] = useState(5);
  const [customGameId, setCustomGameId] = useState(gameId || 'practice-game');

  useEffect(() => {
    setCustomGameId(gameId || 'practice-game');
  }, [gameId]);

  const handleTap = () => {
    if (gameEnded) return;
    const newScore = score + 1;
    setScore(newScore);
    if (newScore >= clicksNeeded) {
      setGameEnded(true);
    }
  };

  const resetGame = () => {
    setScore(0);
    setGameEnded(false);
  };

  // Build target return URL explicitly for display
  const targetSuccessUrl = (() => {
    const base = mainUrl || window.location.origin;
    const separator = base.includes('?') ? '&' : '?';
    return `${base}${separator}game=${encodeURIComponent(customGameId)}&result=success`;
  })();

  const handleSuccessRedirect = () => {
    // Navigate with game & result=success
    const query = `game=${encodeURIComponent(customGameId)}&result=success`;
    onReturnToMain(query);
  };

  return (
    <div className="space-y-6">
      {/* High Density Mini-Game Module Card Container */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden flex flex-col">
        {/* Rose/Slate High Density Header Bar */}
        <div className="bg-rose-500 p-4 flex justify-between items-center text-white">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-white animate-pulse"></div>
            <span className="text-xs font-bold uppercase tracking-widest text-white">
              MINI-GAME MODULE
            </span>
          </div>
          <span className="text-[10px] font-mono bg-rose-600/80 px-2 py-0.5 rounded text-white border border-rose-400/50">
            ID: {customGameId}
          </span>
        </div>

        <div className="p-6 flex flex-col gap-6">
          {/* Header Title Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-rose-50 border border-rose-100 text-rose-700 text-[11px] font-bold mb-2">
                <Gamepad2 className="w-3.5 h-3.5" />
                미니게임 앱 페이지 (Mini Game App Page)
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                미니게임 앱 (Mini Game App)
              </h2>
            </div>

            <button
              onClick={() => onReturnToMain()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors shrink-0 self-start sm:self-auto cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              메인 앱으로 복귀
            </button>
          </div>

          {/* Received Data Inspector Card */}
          <div className="bg-slate-900 text-slate-100 rounded-xl p-4 shadow-md border border-slate-800">
            <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2.5 flex items-center gap-2">
              <Send className="w-3.5 h-3.5 text-indigo-400" />
              메인 앱으로부터 전달받은 프로토콜 데이터
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-400 block text-[10px] mb-1 font-sans">1. 메인 앱 Return Target URL</span>
                <span className="text-indigo-300 font-bold break-all">{mainUrl || window.location.origin}</span>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-400 block text-[10px] mb-1 font-sans">2. 미니게임 ID (game)</span>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={customGameId}
                    onChange={(e) => setCustomGameId(e.target.value)}
                    className="bg-slate-900 border border-slate-700 text-emerald-400 px-2 py-0.5 rounded text-xs font-mono font-bold w-full focus:outline-hidden focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Game Stage Area with Pattern Background */}
          <div className="p-6 bg-slate-50 border border-slate-200 rounded-2xl relative overflow-hidden text-center flex flex-col items-center justify-center">
            {/* Background Dot Pattern matching Design HTML */}
            <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-60 pointer-events-none"></div>

            <div className="relative z-10 w-full max-w-md">
              <div className="w-16 h-16 mx-auto rounded-full bg-white shadow-md border border-slate-200 flex items-center justify-center text-3xl mb-3">
                🕹️
              </div>

              <h3 className="text-lg font-bold text-slate-800 mb-1">
                {gameEnded ? '미니게임 미션 성공!' : '터치 미션 퍼포먼스'}
              </h3>
              <p className="text-xs text-slate-500 mb-5">
                버튼을 {clicksNeeded}번 클릭해 미션을 완료하거나, 아래의 <strong>[게임성공 버튼]</strong>을 클릭하여 리다이렉트를 시뮬레이션하세요.
              </p>

              {/* Interactive Clicker */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm mb-6 text-left">
                <div className="flex justify-between items-center text-xs text-slate-500 mb-1.5 font-medium">
                  <span>터치 진행률</span>
                  <span className="font-bold font-mono text-slate-800">{score} / {clicksNeeded}</span>
                </div>

                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden mb-3 border border-slate-200">
                  <div
                    className="bg-emerald-500 h-full transition-all duration-300"
                    style={{ width: `${Math.min((score / clicksNeeded) * 100, 100)}%` }}
                  ></div>
                </div>

                {!gameEnded ? (
                  <button
                    onClick={handleTap}
                    className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 active:scale-98 text-white font-bold rounded-lg text-xs shadow-sm transition-all cursor-pointer"
                  >
                    터치하기! ({clicksNeeded - score}회 남음)
                  </button>
                ) : (
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      목표 달성 완료!
                    </span>
                    <button
                      onClick={resetGame}
                      className="text-xs text-slate-500 hover:text-slate-800 font-medium inline-flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" /> 다시하기
                    </button>
                  </div>
                )}
              </div>

              {/* CORE REQUIREMENT: 게임성공 버튼 */}
              <div className="bg-white p-5 rounded-2xl border-2 border-emerald-300 shadow-lg text-left relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl pointer-events-none"></div>

                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700 block mb-1">
                  CORE REQUIREMENT PROTOCOL
                </span>
                <h4 className="text-base font-extrabold text-slate-900 mb-1">
                  게임성공 버튼
                </h4>
                <p className="text-xs text-slate-600 mb-4">
                  클릭 시 메인 앱 URL로 <code className="bg-emerald-100 text-emerald-900 px-1 py-0.5 rounded font-mono font-bold">?game={customGameId}&amp;result=success</code> 파라미터를 부착하여 이동합니다.
                </p>

                <button
                  onClick={handleSuccessRedirect}
                  className="w-full bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white font-bold py-4 px-6 rounded-xl shadow-lg shadow-emerald-100 flex items-center justify-center gap-2 cursor-pointer transition-all text-sm"
                >
                  <Trophy className="w-5 h-5 text-amber-300" />
                  <span>게임성공 버튼 (메인 앱으로 복귀)</span>
                </button>

                {/* Target URL Preview */}
                <div className="mt-4 pt-3 border-t border-slate-100">
                  <span className="text-[10px] font-semibold text-slate-500 block mb-1">
                    생성될 최종 리다이렉트 Callback URL:
                  </span>
                  <div className="bg-slate-900 text-emerald-300 p-2.5 rounded-lg text-[11px] font-mono break-all border border-slate-800">
                    {targetSuccessUrl}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
