import React, { useState } from 'react';
import { StampsMap, StampItem } from '../types';
import { UrlFlowDiagram } from './UrlFlowDiagram';
import {
  Copy,
  Check,
  ExternalLink,
  Award,
  RotateCcw,
  Sparkles,
  Smartphone,
  HardDrive,
  Info,
  ArrowRight,
  ShieldAlert
} from 'lucide-react';

interface Props {
  myUrl: string;
  stamps: StampsMap;
  lastProcessedGame: string | null;
  onNavigateToMiniGame: (gameId: string) => void;
  onResetStamps: () => void;
}

export const MainApp: React.FC<Props> = ({
  myUrl,
  stamps,
  lastProcessedGame,
  onNavigateToMiniGame,
  onResetStamps,
}) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'stamps' | 'storage' | 'guide'>('stamps');

  const copyToClipboard = () => {
    navigator.clipboard.writeText(myUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const practiceGame = stamps['practice-game'] || {
    gameId: 'practice-game',
    gameName: '연습 미니게임',
    acquired: false,
  };

  return (
    <div className="space-y-6">
      {/* High Density Card Container for Main App */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden flex flex-col">
        {/* Module Header Bar */}
        <div className="bg-slate-900 p-4 flex justify-between items-center text-white">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
            <span className="text-xs font-bold uppercase tracking-widest text-slate-100">
              MAIN APPLICATION MODULE
            </span>
          </div>
          <span className="text-[10px] font-mono bg-slate-800 px-2 py-0.5 rounded text-slate-400 border border-slate-700">
            ID: 0x82F1 • LOCALHOST
          </span>
        </div>

        <div className="p-6 flex flex-col gap-6">
          {/* Header Description */}
          <div>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-indigo-50 border border-indigo-100 text-indigo-700 text-[11px] font-bold mb-2">
              <Smartphone className="w-3.5 h-3.5" />
              메인 앱 페이지 (Main App Page)
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
              메인 앱 (Main App)
            </h2>
            <p className="text-slate-500 text-xs sm:text-sm mt-1">
              미니게임과의 URL 파라미터 데이터 연동 및 스탬프 획득 처리 시스템
            </p>
          </div>

          {/* Success Notification Banner when return URL processed */}
          {lastProcessedGame && (
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-start gap-3 shadow-xs">
              <div className="p-2 bg-emerald-500 text-white rounded-lg shrink-0 mt-0.5">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-emerald-950">
                  🎉 축하합니다! 스탬프가 성공적으로 수집되었습니다!
                </h4>
                <p className="text-xs text-emerald-800 mt-1">
                  URL 파라미터 <code className="bg-emerald-100 px-1.5 py-0.5 rounded font-mono text-emerald-900">game={lastProcessedGame}&amp;result=success</code>를 감지하여 <strong>localStorage.stamps</strong>에 저장하였습니다.
                </p>
                <div className="mt-2 text-[11px] text-emerald-700 font-medium flex items-center gap-1.5 bg-emerald-100/60 px-2.5 py-1 rounded-md w-fit">
                  <ShieldAlert className="w-3.5 h-3.5 text-emerald-600" />
                  URL의 query parameter가 자동으로 정화되어 새로고침 시 중복 저장이 방지됩니다.
                </div>
              </div>
            </div>
          )}

          {/* Section 1: 나의 URL */}
          <section className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <label className="text-[11px] uppercase font-bold text-slate-500 tracking-wider block">
                1. MY ENDPOINT URL (나의 URL 생성)
              </label>
              <span className="text-[10px] font-mono text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                Current Origin
              </span>
            </div>
            <p className="text-xs text-slate-500 mb-3">
              미니게임 앱으로 이동할 때 전달되는 메인 앱의 고유 주소입니다. 미니게임 완료 후 이 주소로 복귀하게 됩니다.
            </p>
            <div className="flex flex-col sm:flex-row items-stretch gap-2">
              <div className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono text-slate-700 flex items-center overflow-x-auto shadow-inner">
                <span className="select-all truncate">{myUrl}</span>
              </div>
              <button
                onClick={copyToClipboard}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-lg text-xs font-semibold shadow-xs transition-colors shrink-0 cursor-pointer"
                title="URL 복사"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    복사됨!
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    URL 복사
                  </>
                )}
              </button>
            </div>
          </section>

          {/* Section 2: 미니게임 목록 & 스탬프 상태 */}
          <section className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <label className="text-[11px] uppercase font-bold text-slate-500 tracking-wider flex items-center gap-1.5">
                <Award className="w-4 h-4 text-indigo-600" />
                2. MISSIONS &amp; STAMPS (미니게임 연동 &amp; 스탬프 현황)
              </label>
              <button
                onClick={onResetStamps}
                className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md text-xs font-medium transition-colors cursor-pointer"
                title="스탬프 초기화"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                초기화
              </button>
            </div>

            {/* High Density Theme Practice Game Stamp Box */}
            <div
              className={`p-4 sm:p-5 rounded-xl border-2 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                practiceGame.acquired
                  ? 'border-emerald-500 bg-emerald-50/70 shadow-sm'
                  : 'border-slate-200 bg-slate-50/80 hover:border-indigo-300'
              }`}
            >
              <div className="flex items-center gap-4">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center text-xl transition-all shadow-sm ${
                    practiceGame.acquired
                      ? 'bg-emerald-500 text-white border-2 border-emerald-500'
                      : 'bg-slate-100 text-slate-400 border-2 border-dashed border-slate-300'
                  }`}
                >
                  {practiceGame.acquired ? '✔️' : '?'}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-slate-900 text-base">practice-game</h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-100 text-indigo-700 font-bold">
                      요청 스펙 지정 게임
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    클릭 시 <code className="bg-white border border-slate-200 px-1 rounded font-mono text-[11px]">practice-game</code> 미니게임으로 이동합니다.
                  </p>
                  <p className="text-[10px] font-mono uppercase mt-1">
                    상태:{' '}
                    <span className={practiceGame.acquired ? 'text-emerald-600 font-bold' : 'text-slate-400 font-medium'}>
                      {practiceGame.acquired ? 'ACQUIRED (획득됨)' : 'NOT ACQUIRED (미획득)'}
                    </span>
                  </p>
                </div>
              </div>

              <button
                onClick={() => onNavigateToMiniGame('practice-game')}
                className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-5 rounded-xl shadow-lg shadow-indigo-100 flex items-center justify-center gap-2 transition-all cursor-pointer text-xs shrink-0"
              >
                <span>미니게임 버튼 (이동)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Other Games Example Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              {(Object.values(stamps) as StampItem[])
                .filter((g) => g.gameId !== 'practice-game')
                .map((game) => (
                  <div
                    key={game.gameId}
                    className="p-3 rounded-lg border border-slate-200 bg-white flex items-center justify-between"
                  >
                    <div>
                      <div className="font-semibold text-xs text-slate-800">{game.gameName}</div>
                      <div className="text-[10px] font-mono text-slate-400">{game.gameId}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      {game.acquired ? (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-700">
                          획득
                        </span>
                      ) : (
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-500">
                          미획득
                        </span>
                      )}
                      <button
                        onClick={() => onNavigateToMiniGame(game.gameId)}
                        className="p-1.5 bg-slate-50 border border-slate-200 rounded text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 transition-colors cursor-pointer"
                        title="게임 플레이"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </section>
        </div>
      </div>

      {/* Flow Diagram */}
      <UrlFlowDiagram currentStep={lastProcessedGame ? 3 : 1} />

      {/* High Density Tabs: LocalStorage Inspector & System Guide */}
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="flex border-b border-slate-200 bg-slate-900">
          <button
            onClick={() => setActiveTab('stamps')}
            className={`flex-1 py-3 px-4 text-xs font-bold text-center transition-colors cursor-pointer ${
              activeTab === 'stamps'
                ? 'bg-white text-indigo-700 border-t-2 border-indigo-600'
                : 'text-slate-400 hover:text-white bg-slate-900'
            }`}
          >
            localStorage.stamps 객체 실시간 상태
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`flex-1 py-3 px-4 text-xs font-bold text-center transition-colors cursor-pointer ${
              activeTab === 'guide'
                ? 'bg-white text-indigo-700 border-t-2 border-indigo-600'
                : 'text-slate-400 hover:text-white bg-slate-900'
            }`}
          >
            동작 원리 &amp; 프로토콜 규격
          </button>
        </div>

        <div className="p-5">
          {activeTab === 'stamps' || activeTab === 'storage' ? (
            <div>
              <div className="flex items-center justify-between mb-2">
                <div className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <HardDrive className="w-4 h-4 text-indigo-600" />
                  localStorage ('stamps') JSON 데이터 객체
                </div>
                <span className="text-[10px] text-slate-400 font-mono">Key: stamps</span>
              </div>
              <pre className="bg-slate-900 text-emerald-400 p-4 rounded-xl text-xs font-mono overflow-x-auto border border-slate-800 leading-relaxed shadow-inner">
                {JSON.stringify(stamps, null, 2)}
              </pre>
            </div>
          ) : (
            <div className="space-y-4 text-xs text-slate-600 leading-relaxed">
              <div className="bg-indigo-50/70 p-3.5 rounded-xl border border-indigo-100">
                <h5 className="font-bold text-indigo-950 text-xs mb-1 flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-indigo-600" />
                  URL Parameter 연동 프로토콜 명세
                </h5>
                <p className="text-slate-700">
                  독립된 웹 페이지나 앱 환경 사이에서 상태를 주고받는 가장 경량화된 방식은 <strong>URL Query Parameter</strong>를 활용하는 것입니다.
                </p>
              </div>

              <div className="space-y-3">
                <div>
                  <h6 className="font-bold text-slate-800 text-xs mb-1">1. 메인 앱에서 미니게임으로 이동 시</h6>
                  <code className="block bg-slate-900 text-slate-200 p-2.5 rounded-lg font-mono text-[11px] border border-slate-800">
                    {`const targetMiniGameUrl = \`/game?gameId=practice-game&mainUrl=\${encodeURIComponent(myUrl)}\`;`}
                  </code>
                </div>

                <div>
                  <h6 className="font-bold text-slate-800 text-xs mb-1">2. 미니게임 완료 후 성공 시 메인 앱으로 리다이렉트</h6>
                  <code className="block bg-slate-900 text-emerald-300 p-2.5 rounded-lg font-mono text-[11px] border border-slate-800">
                    {`window.location.href = \`\${mainUrl}?game=practice-game&result=success\`;`}
                  </code>
                </div>

                <div>
                  <h6 className="font-bold text-slate-800 text-xs mb-1">3. 메인 앱 도착 후 자동 저장 및 URL 정화</h6>
                  <code className="block bg-slate-900 text-amber-300 p-2.5 rounded-lg font-mono text-[11px] border border-slate-800 leading-relaxed">
                    {`const params = new URLSearchParams(window.location.search);
if (params.get('game') && params.get('result') === 'success') {
  // 1) localStorage 저장
  saveStamp(params.get('game'));
  
  // 2) URL 정화 (새로고침 시 중복 저장 방지)
  const cleanUrl = window.location.pathname;
  window.history.replaceState({}, document.title, cleanUrl);
}`}
                  </code>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
