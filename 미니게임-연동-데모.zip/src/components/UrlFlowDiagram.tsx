import React from 'react';
import { ArrowRight, CheckCircle2, Gamepad2, Smartphone, HardDrive, RefreshCw } from 'lucide-react';

interface Props {
  currentStep: 1 | 2 | 3;
}

export const UrlFlowDiagram: React.FC<Props> = ({ currentStep }) => {
  return (
    <div className="bg-slate-900 text-slate-100 rounded-2xl p-5 shadow-xl border border-slate-800 my-6">
      <div className="flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
        <h3 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
          <RefreshCw className="w-4 h-4 text-indigo-400" />
          메인 앱 ↔ 미니게임 연동 원리 흐름도
        </h3>
        <span className="text-xs px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
          URL Query Parameter 방식
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Step 1 */}
        <div
          className={`p-4 rounded-xl border transition-all ${
            currentStep === 1
              ? 'bg-indigo-950/60 border-indigo-500/80 ring-2 ring-indigo-500/30'
              : 'bg-slate-800/40 border-slate-700/50 opacity-80'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-indigo-400">STEP 1</span>
            <Smartphone className="w-4 h-4 text-indigo-400" />
          </div>
          <h4 className="text-sm font-bold text-white mb-1">1. 나의 URL 전달</h4>
          <p className="text-xs text-slate-400 mb-2 leading-relaxed">
            메인 앱에서 미니게임으로 이동할 때 <strong>자신의 Return URL</strong>을 함께 전달합니다.
          </p>
          <div className="bg-slate-950 p-2 rounded text-[11px] font-mono text-indigo-300 border border-slate-800 truncate">
            /game?mainUrl=http://...
          </div>
        </div>

        {/* Step 2 */}
        <div
          className={`p-4 rounded-xl border transition-all ${
            currentStep === 2
              ? 'bg-emerald-950/60 border-emerald-500/80 ring-2 ring-emerald-500/30'
              : 'bg-slate-800/40 border-slate-700/50 opacity-80'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-emerald-400">STEP 2</span>
            <Gamepad2 className="w-4 h-4 text-emerald-400" />
          </div>
          <h4 className="text-sm font-bold text-white mb-1">2. 성공 시 리다이렉트</h4>
          <p className="text-xs text-slate-400 mb-2 leading-relaxed">
            미니게임 성공 버튼 클릭 시 파라미터를 붙여 메인 앱으로 돌아갑니다.
          </p>
          <div className="bg-slate-950 p-2 rounded text-[11px] font-mono text-emerald-300 border border-slate-800 truncate">
            MainUrl?game=practice-game&result=success
          </div>
        </div>

        {/* Step 3 */}
        <div
          className={`p-4 rounded-xl border transition-all ${
            currentStep === 3
              ? 'bg-amber-950/60 border-amber-500/80 ring-2 ring-amber-500/30'
              : 'bg-slate-800/40 border-slate-700/50 opacity-80'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-amber-400">STEP 3</span>
            <HardDrive className="w-4 h-4 text-amber-400" />
          </div>
          <h4 className="text-sm font-bold text-white mb-1">3. 저장 & URL 정화</h4>
          <p className="text-xs text-slate-400 mb-2 leading-relaxed">
            localStorage에 획득 기록 후, 새로고침 중복 방지를 위해 URL 파라미터를 제거합니다.
          </p>
          <div className="bg-slate-950 p-2 rounded text-[11px] font-mono text-amber-300 border border-slate-800 truncate">
            history.replaceState({}, '', cleanUrl)
          </div>
        </div>
      </div>
    </div>
  );
};
